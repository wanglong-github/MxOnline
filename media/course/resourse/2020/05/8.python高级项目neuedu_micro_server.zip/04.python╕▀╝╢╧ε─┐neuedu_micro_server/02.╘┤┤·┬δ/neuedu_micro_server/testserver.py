from wsgiref.simple_server import make_server, demo_app
from app import app
if __name__ == '__main__':
    httpd = make_server(host='', port=8000, app=app)
    print("Serving HTTP on port 8000...")
    httpd.serve_forever()